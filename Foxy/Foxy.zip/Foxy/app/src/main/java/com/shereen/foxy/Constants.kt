package com.shereen.foxy

class Constants {

    companion object {

        const val LOGGER = "FOXAPP"

        const val DATABASE_NAME = "foxydb"
        const val RESPONSE_TABLE = "response"
        const val TAG = "FOXY_APP"

    }
}