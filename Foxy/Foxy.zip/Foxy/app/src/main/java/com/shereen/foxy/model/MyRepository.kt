package com.shereen.foxy.model

import android.util.Log
import androidx.annotation.WorkerThread
import androidx.lifecycle.LiveData
import com.shereen.foxy.Constants
import com.shereen.foxy.model.retrofit.RetrofitFactory
import com.shereen.foxy.model.room.ResponseDao
import com.shereen.foxy.model.room.ResponseEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.lang.Exception

class MyRepository(private val responseDao: ResponseDao) {

    val retrofitService = RetrofitFactory.makeRetrofitService()

//    val oneImage: LiveData<ResponseEntity> = responseDao.getOne()
//
//    val allImages: LiveData<List<ResponseEntity>> = responseDao.getAll()

    fun requestFox(){
        GlobalScope.launch(Dispatchers.Main) {
            val request = retrofitService.makeFoxCall()
            try{
                val response = request.await()
                Log.d(Constants.LOGGER, response.body().toString())
                //save to db
                deleteAllImages()
                if (response.body() != null) {
                    insertOneImage(response.body()!!)
                }
            } catch(e: Exception){
                Log.d(Constants.LOGGER, e.toString())
            }
        }
    }


    fun insertOneImage(response: ResponseEntity): Job{
        return launch {
            responseDao.insert(response)
        }
    }

    suspend fun deleteAllImages(){
        responseDao.deleteAll()
    }

}