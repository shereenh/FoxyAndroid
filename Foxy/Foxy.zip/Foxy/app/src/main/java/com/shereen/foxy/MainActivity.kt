package com.shereen.foxy

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProviders
import com.shereen.foxy.model.MyRepository
import com.shereen.foxy.model.retrofit.RetrofitFactory
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.lang.Exception
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    var imageString = "http://randomfox.ca/images/78.jpg"
    lateinit var mViewModel : MyViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mViewModel = ViewModelProviders.of(this).get(MyViewModel::class.java)

        changeFoxButton.setOnClickListener{
            setImage(imageString)
        }
    }

    fun setImage(img: String){

        getPicasso(this).load("https://randomfox.ca/images/78.jpg")
            .resize(500,500)
            .centerCrop()
            .into(foxImageView)

        mViewModel.getAFox()
    }

    fun getPicasso(con: Context):Picasso{

        return Picasso.Builder(con)
            .loggingEnabled(true)
            .build()
    }

    fun toast(mes: String){
        Toast.makeText(this, mes, Toast.LENGTH_SHORT).show()
    }

}
